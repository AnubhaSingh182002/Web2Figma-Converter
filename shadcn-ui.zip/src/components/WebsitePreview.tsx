import React, { useState } from "react";
import { ConversionResult } from "@/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Eye, Download, Layers } from "lucide-react";

interface WebsitePreviewProps {
  result: ConversionResult;
}

export default function WebsitePreview({ result }: WebsitePreviewProps) {
  const [viewMode, setViewMode] = useState<"preview" | "elements" | "code">("preview");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold">Design Preview</h3>
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === "preview" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("preview")}
          >
            <Eye className="h-4 w-4 mr-1" />
            Preview
          </Button>
          <Button
            variant={viewMode === "elements" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("elements")}
          >
            <Layers className="h-4 w-4 mr-1" />
            Elements
          </Button>
          <Button
            variant={viewMode === "code" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("code")}
          >
            <Download className="h-4 w-4 mr-1" />
            CSS
          </Button>
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden bg-white">
        <div className="p-2 bg-gray-50 border-b flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="text-xs text-gray-500 bg-white border rounded-md px-2 py-1 flex-1 text-center">
            {result.url}
          </div>
        </div>

        {viewMode === "preview" && (
          <div 
            className="h-[500px] overflow-auto" 
            style={{ 
              backgroundSize: "cover", 
              backgroundPosition: "top center",
              backgroundImage: `url(data:image/png;base64,${result.previewImage})` 
            }}
          >
            <div className="w-full h-full relative flex items-center justify-center">
              {!result.previewImage && (
                <div className="text-gray-400">Preview image not available</div>
              )}
            </div>
          </div>
        )}

        {viewMode === "elements" && (
          <div className="h-[500px] overflow-auto p-4">
            <ul className="space-y-2">
              {result.elements.map((element, index) => (
                <li key={index} className="p-2 border rounded flex items-center gap-2">
                  <div 
                    className="w-6 h-6 rounded-sm" 
                    style={{ backgroundColor: element.color || '#eeeeee' }}
                  ></div>
                  <div className="flex-1">
                    <div className="font-mono text-sm">{element.type}</div>
                    <div className="text-xs text-gray-500">
                      {element.width}x{element.height} - {element.position}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
        
        {viewMode === "code" && (
          <div className="h-[500px] overflow-auto">
            <pre className="p-4 text-sm font-mono whitespace-pre-wrap">
              {result.css}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}