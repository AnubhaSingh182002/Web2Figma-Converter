import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface UrlFormProps {
  onSubmit: (url: string) => void;
  isProcessing: boolean;
}

export default function UrlForm({ onSubmit, isProcessing }: UrlFormProps) {
  const [url, setUrl] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  const validateUrl = (input: string): boolean => {
    try {
      // Basic URL validation
      const url = new URL(input);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset previous error
    setError(null);

    // Validate URL
    if (!url.trim()) {
      setError("Please enter a URL");
      return;
    }

    if (!validateUrl(url)) {
      setError("Please enter a valid URL (e.g., https://example.com)");
      return;
    }

    // Submit the URL
    onSubmit(url);
  };

  const handleDemoClick = () => {
    const demoUrl = "https://www.figma.com";
    setUrl(demoUrl);
    onSubmit(demoUrl);
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="url">Website URL</Label>
          <Input
            id="url"
            type="text"
            placeholder="https://example.com"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            disabled={isProcessing}
            className="h-12"
          />
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="flex gap-4">
          <Button
            type="submit"
            disabled={isProcessing}
            className="w-full h-10"
          >
            {isProcessing ? "Processing..." : "Convert to Figma Design"}
          </Button>
        </div>
      </form>

      <div className="pt-2 border-t">
        <p className="text-sm text-muted-foreground mb-2">
          Not sure where to start? Try one of our examples:
        </p>
        <Button
          variant="outline"
          onClick={handleDemoClick}
          disabled={isProcessing}
          className="text-sm"
        >
          Try with Figma.com
        </Button>
      </div>
    </div>
  );
}