import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ConversionResult } from "@/types";
import {
  Download,
  Copy,
  RefreshCw,
  FileJson,
  Share2,
  Figma,
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface ExportOptionsProps {
  result: ConversionResult;
  onReset: () => void;
}

export default function ExportOptions({ result, onReset }: ExportOptionsProps) {
  const [exportFormat, setExportFormat] = useState<"figma" | "json" | "html">("figma");
  const { toast } = useToast();

  const handleExport = () => {
    // Simulate export process
    toast({
      title: "Export successful!",
      description: `Design has been exported in ${exportFormat} format.`,
    });

    // In a real application, this would trigger a download
    // or open Figma with the design
    if (exportFormat === "figma") {
      window.open("https://www.figma.com/file/new", "_blank");
    }
  };

  const handleCopyJson = () => {
    // Copy the JSON representation to clipboard
    navigator.clipboard.writeText(JSON.stringify(result, null, 2))
      .then(() => {
        toast({
          title: "Copied to clipboard",
          description: "JSON data has been copied to your clipboard.",
        });
      })
      .catch((err) => {
        toast({
          variant: "destructive",
          title: "Failed to copy",
          description: "Could not copy to clipboard. Please try again.",
        });
      });
  };

  const handleShare = () => {
    toast({
      title: "Share link created",
      description: "A shareable link has been copied to your clipboard.",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold mb-4">Export Options</h3>
        
        <Tabs value={exportFormat} onValueChange={(v) => setExportFormat(v as "figma" | "json" | "html")}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="figma" className="flex items-center gap-1">
              <Figma className="h-4 w-4" />
              Figma
            </TabsTrigger>
            <TabsTrigger value="json" className="flex items-center gap-1">
              <FileJson className="h-4 w-4" />
              JSON
            </TabsTrigger>
            <TabsTrigger value="html" className="flex items-center gap-1">
              <FileJson className="h-4 w-4" />
              HTML/CSS
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="figma">
            <div className="bg-gray-50 border rounded-md p-4 mb-4">
              <p className="text-sm text-muted-foreground mb-2">
                Export your design directly to Figma. This will create a new Figma file with your website design.
              </p>
              <div className="flex items-center gap-2">
                <Button onClick={handleExport} className="flex items-center gap-2">
                  <Figma className="h-4 w-4" />
                  Export to Figma
                </Button>
                <Button onClick={handleShare} variant="outline">
                  <Share2 className="h-4 w-4 mr-1" />
                  Share
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="json">
            <div className="bg-gray-50 border rounded-md p-4 mb-4">
              <p className="text-sm text-muted-foreground mb-2">
                Export the design as JSON data, which can be imported into other design tools.
              </p>
              <Button onClick={handleCopyJson} variant="outline" className="flex items-center gap-2">
                <Copy className="h-4 w-4" />
                Copy JSON
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="html">
            <div className="bg-gray-50 border rounded-md p-4 mb-4">
              <p className="text-sm text-muted-foreground mb-2">
                Export the generated HTML and CSS for your design.
              </p>
              <Button onClick={handleExport} className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                Download HTML/CSS
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <div className="flex items-center justify-between pt-4 border-t">
        <div>
          <p className="text-sm text-muted-foreground">
            Created on: {new Date().toLocaleDateString()}
          </p>
        </div>
        <Button variant="ghost" onClick={onReset} className="flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Start New Conversion
        </Button>
      </div>
    </div>
  );
}