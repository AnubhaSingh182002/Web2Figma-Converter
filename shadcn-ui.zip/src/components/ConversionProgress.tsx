import React, { useEffect, useState } from "react";
import { Progress } from "@/components/ui/progress";
import { ConversionStatus } from "@/types";
import { Check, AlertCircle, Loader2 } from "lucide-react";

interface ConversionProgressProps {
  progress: number;
  status: ConversionStatus;
  url: string;
}

export default function ConversionProgress({ 
  progress, 
  status, 
  url 
}: ConversionProgressProps) {
  const [steps, setSteps] = useState([
    { name: "Fetching website content", completed: false, current: false },
    { name: "Analyzing DOM structure", completed: false, current: false },
    { name: "Extracting styles and assets", completed: false, current: false },
    { name: "Creating Figma components", completed: false, current: false },
    { name: "Finalizing design prototype", completed: false, current: false },
  ]);

  // Update steps based on progress
  useEffect(() => {
    if (status === "idle" || status === "error") return;

    const currentStepIndex = Math.min(
      Math.floor(progress / 20),
      steps.length - 1
    );

    const updatedSteps = steps.map((step, index) => ({
      ...step,
      completed: index < currentStepIndex,
      current: index === currentStepIndex,
    }));

    setSteps(updatedSteps);
  }, [progress, status]);

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-medium">Converting website</h3>
          <span className="text-sm text-muted-foreground">{progress}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <div className="space-y-1 mt-6">
        <h3 className="text-sm font-medium mb-3">URL: {url}</h3>

        {status === "error" ? (
          <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
            <AlertCircle className="h-5 w-5" />
            <span>Conversion failed. Please try again or try a different URL.</span>
          </div>
        ) : (
          <ul className="space-y-4">
            {steps.map((step, index) => (
              <li key={index} className="flex items-center gap-3">
                {step.completed ? (
                  <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                ) : step.current ? (
                  <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center">
                    <Loader2 className="h-4 w-4 text-blue-600 animate-spin" />
                  </div>
                ) : (
                  <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center">
                    <span className="text-xs text-gray-500">{index + 1}</span>
                  </div>
                )}
                <span className={`text-sm ${step.current ? "font-medium" : ""}`}>{step.name}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="mt-6 text-sm text-muted-foreground">
        {status === "processing" && (
          <div className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span>Processing... This might take a minute.</span>
          </div>
        )}
      </div>
    </div>
  );
}