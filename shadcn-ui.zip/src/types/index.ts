/**
 * Types for the Web2Figma Converter application
 */

/**
 * Status of the website-to-design conversion process
 */
export type ConversionStatus = "idle" | "processing" | "completed" | "error";

/**
 * Represents a design element in the converted Figma prototype
 */
export interface DesignElement {
  type: string;
  color?: string;
  width?: string;
  height?: string;
  position?: string;
  children?: DesignElement[];
  [key: string]: string | number | boolean | object | undefined; // For additional properties
}

/**
 * Figma-specific metadata for the converted design
 */
export interface FigmaMetadata {
  fileKey: string;
  nodeId: string;
  [key: string]: string | number | boolean | object | undefined; // For additional Figma-specific properties
}

/**
 * The result of converting a website to a Figma design prototype
 */
export interface ConversionResult {
  url: string;
  title: string;
  previewImage: string; // Base64-encoded image data
  elements: DesignElement[];
  figmaData: FigmaMetadata;
  css: string;
  convertedAt: string; // ISO date string
}