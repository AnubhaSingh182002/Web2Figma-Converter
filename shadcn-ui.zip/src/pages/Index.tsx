import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import UrlForm from "@/components/UrlForm";
import WebsitePreview from "@/components/WebsitePreview";
import ConversionProgress from "@/components/ConversionProgress";
import ExportOptions from "@/components/ExportOptions";
import { ConversionResult, ConversionStatus } from "@/types";
import { convertWebsiteToFigma } from "@/lib/converter";

export default function Index() {
  const [url, setUrl] = useState<string>("");
  const [status, setStatus] = useState<ConversionStatus>("idle");
  const [progress, setProgress] = useState<number>(0);
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [activeTab, setActiveTab] = useState<string>("input");
  const { toast } = useToast();

  const handleSubmit = async (submittedUrl: string) => {
    try {
      setUrl(submittedUrl);
      setStatus("processing");
      setProgress(0);
      setActiveTab("progress");

      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 10;
          if (newProgress >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return newProgress;
        });
      }, 500);

      // Process the URL and convert to Figma design
      const conversionResult = await convertWebsiteToFigma(submittedUrl, (p) => {
        setProgress(p);
      });

      clearInterval(progressInterval);
      setProgress(100);
      setResult(conversionResult);
      setStatus("completed");
      setActiveTab("preview");

      toast({
        title: "Conversion complete",
        description: "Your website has been converted to a Figma design prototype.",
      });
    } catch (error) {
      setStatus("error");
      toast({
        variant: "destructive",
        title: "Conversion failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
      });
    }
  };

  const handleReset = () => {
    setUrl("");
    setStatus("idle");
    setProgress(0);
    setResult(null);
    setActiveTab("input");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="text-center space-y-3">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Web2Figma Converter
          </h1>
          <p className="text-lg text-muted-foreground">
            Transform any website into a Figma design prototype with just one click
          </p>
        </div>

        <Card className="p-6 shadow-lg">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="input" disabled={status === "processing"}>
                Input URL
              </TabsTrigger>
              <TabsTrigger 
                value="progress" 
                disabled={status === "idle" || status === "error"}
              >
                Processing
              </TabsTrigger>
              <TabsTrigger 
                value="preview" 
                disabled={status !== "completed"}
              >
                Preview & Export
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="input">
              <UrlForm onSubmit={handleSubmit} isProcessing={status === "processing"} />
            </TabsContent>
            
            <TabsContent value="progress">
              <ConversionProgress progress={progress} status={status} url={url} />
            </TabsContent>
            
            <TabsContent value="preview">
              {result && (
                <div className="space-y-8">
                  <WebsitePreview result={result} />
                  <ExportOptions result={result} onReset={handleReset} />
                </div>
              )}
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}